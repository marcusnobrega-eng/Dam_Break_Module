% Water Depth Profile
wse = inv_el + y; % water surface elevation in meters
for n=1:1:(Nt/Nat)
startColor = [0, 0, 0];
     if n == 1
        t = 1;
        pos = 1;
    else
        t=(n-1)*Nat*dt;
        pos = t/dt;
    end
    plot(x,inv_el,'LineWidth',4,'LineStyle','-','Color','black')
    hold on
    plot(x,wse(:,pos),'k','LineWidth',2,'LineStyle',':','Color',startColor + 1*n/(Nt/Nat))
    xlabel('x [m]','Interpreter','latex');
    ylabel('Water surface Elevation [m]','Interpreter','latex');
    ylim([0.98*min(min(wse - y)) max(max(1.01*wse))])
    grid on
    hold on
    plot([L_comunity L_comunity],[0 max(max(wse))],'LineWidth',4,'LineStyle','--','Color','red')
    hold on
end
