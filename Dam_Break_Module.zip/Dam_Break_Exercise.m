%%% Dam Break Algorithm %%%
% Developer: Marcus Nobrega Gomes Junior
% 5/18/2022
% Solution of SVE for given cross-section functions of Area, Perimeter, and
% top Width

%%% Goal - Solve 1-D Dam Break %%%

%% Input-Data
% Dam Data
% The input data should be a row vector with
% 1 - Label of the dam
% 2 - Height of the dam in (m)
% 3 - Dam width (m)
% 4 - Dam Length (m)
% 5 - Length from the dam to the comunity (m)
% 6 - Length of the comunity (m)
% 7 - Roughness coefficient before the city
% 8 - Roughness coefficient after the city
% 9 - Time-step in sec
% 10 - End of the simulation (min)
% 11 - Animation Time (min)
% 12 - Number of sub-reaches
% 13 - Elevation of the first node (m)
% 14 - Average slope (m/m)

label = 1;
y0_r = 1; % Height of the dam in (m)
b_0 = 1; % Dam width (m)
L_r = 1; % Dam Length (m)
L_comunity = 1; % Length from the dam to the comunity (m)
W_comunity = 1; % Length of the comunity (m)
n_j = 1; % Roughness coefficient before the city
n_c = 1; % Roughness coefficient after the city
dt = 1; % sec
tf = 1;% min
animation_time = 1; % min
Nx = 1000; % Number of sub-reaches
el = 100; % Elevation of the dam
I0 = 0.5/1000; % Average slope m/m



input = [80,11,130,1958.05,17840,5710,0.02,0.013,2,30,0.5,1000,100,0.0005];


%% 1-D Solver
% [final_parameters,time_arrival] = Dam_Break_Function(label,y0_r, b_0, L_r, L_comunity, W_comunity, n_j, n_c,dt,tf,animation_time,Nx,el,I0)
[final_parameters,time_arrival] = Dam_Break_Function(input(1),input(2),input(3),input(4),input(5),input(6), input(7),input(8),input(9),input(10),input(11),input(12),input(13),input(14));



