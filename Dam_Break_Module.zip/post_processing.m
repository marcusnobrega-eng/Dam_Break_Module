%% Post Processing Graphs
clf
close all

set(gcf,'units','inches','position',[2,0,8,10])

% Surfplot
t_save = [0:Nat:tf/dt]; t_save(1,1) = 1;
subplot(3,1,1)
surf(x,tint(t_save)/60/60,Fr(:,t_save)');
view(0,90);
kk = colorbar ; colormap('jet')
shading interp
xlabel('x (m)','Interpreter','latex')
ylabel('t (h)','Interpreter','latex')
ylabel(kk,'Froude Number','Interpreter','latex')
zlabel ('Froude Number','Interpreter','Latex');
xlim([0 L]);
ylim([0 tt/60/60]);
set(gca,'FontName','Garamond','FontSize',12,'FontWeight','Bold','LineWidth', 1.5);
set(gca,'TickLength',[0.02 0.01])
set(gca,'TickDir','out')

subplot(3,1,2)
surf(x,tint(t_save)/60/60,y(:,t_save)');
view(0,90);
kk = colorbar ; colormap('jet')
shading interp
xlabel('x (m)','Interpreter','latex')
ylabel('t (h)','Interpreter','latex')
ylabel(kk,'y (m)','Interpreter','latex')
zlabel ('y (m)','Interpreter','Latex');
set(gca,'FontName','Garamond','FontSize',12,'FontWeight','Bold','LineWidth', 1.5);
set(gca,'TickLength',[0.02 0.01])
set(gca,'TickDir','out')
xlim([0 L]);
ylim([0 tf/60/60]);
subplot(3,1,3)
wse = y + inv_el;
surf(x,tint(t_save)/60/60,wse(:,t_save)');
view(0,90);
kk = colorbar ; colormap('jet')
shading interp
xlabel('x (m)','Interpreter','latex')
ylabel('t (h)','Interpreter','latex')
ylabel(kk,'WSE (m)','Interpreter','latex')
zlabel ('WSE (m)','Interpreter','Latex');
xlim([0 L]);
ylim([0 tf/60/60]);
set(gca,'FontName','Garamond','FontSize',12,'FontWeight','Bold','LineWidth', 1.5);
set(gca,'TickLength',[0.02 0.01])
set(gca,'TickDir','out')
fig = sprintf('Surf_Plots_%d.pdf',name_label);
exportgraphics(gcf,fig,'ContentType','image','Colorspace','rgb','Resolution',600)
clf
close all



%% Plots
set(gcf,'units','inches','position',[2,0,8,10])
subplot(3,2,1)
% Flows
plot(tint/60,q2(Nx_r,:),'LineStyle','--','LineWidth',2,'Color','red')
hold on
plot(tint/60,q2(Nx_comunity,:),'LineStyle',':','LineWidth',2,'Color','blue')
hold on
plot(tint/60,q2(Nx,:),'LineStyle','-','LineWidth',2,'Color','green')
hold on
xlabel('Elapsed Time (min)','Interpreter','latex');
ylabel('Flow Discharge (m\textsuperscript{3}/s)','Interpreter','latex');
l = legend('Dam Outlet','Comunity Entrance','Domain Outlet','Interpreter','Latex');
l.NumColumns = 1;
l.Location = 'best';
% Velocity
subplot(3,2,2)
plot(tint/60,q2(Nx_r,:)./q1(1,:),'LineStyle','--','LineWidth',2,'Color','red')
hold on
plot(tint/60,q2(Nx_comunity,:)./q1(Nx_comunity,:),'LineStyle',':','LineWidth',2,'Color','blue')
hold on
plot(tint/60,q2(Nx,:)./q1(Nx,:),'LineStyle','-','LineWidth',2,'Color','green')
xlabel('Elapsed Time (min)','Interpreter','latex');
ylabel('Velocity (m/s)','Interpreter','latex');
% Water Depth
subplot(3,2,3)
plot(tint/60,y(Nx_r,:),'LineStyle','--','LineWidth',2,'Color','red')
hold on
plot(tint/60,y(Nx_comunity,:),'LineStyle',':','LineWidth',2,'Color','blue')
hold on
plot(tint/60,y(Nx,:),'LineStyle','-','LineWidth',2,'Color','green')
xlabel('Elapsed Time (min)','Interpreter','latex');
ylabel('Water Depths (m)','Interpreter','latex');
legend('Dam Outlet','Comunity Entrance','Domain Outlet','Interpreter','Latex')
% Froude Number
subplot(3,2,4)
plot(tint/60,Fr(Nx_r,:),'LineStyle','--','LineWidth',2,'Color','red')
hold on
plot(tint/60,Fr(Nx_comunity,:),'LineStyle',':','LineWidth',2,'Color','blue')
hold on
plot(tint/60,Fr(Nx,:),'LineStyle','-','LineWidth',2,'Color','green')
xlabel('Elapsed Time (min)','Interpreter','latex');
ylabel('Froude Number','Interpreter','latex');

% Courant Number
subplot(3,2,5)
plot(tint/60,Cn(Nx_r,:),'LineStyle','--','LineWidth',2,'Color','red')
hold on
plot(tint/60,Cn(Nx_comunity,:),'LineStyle',':','LineWidth',2,'Color','blue')
hold on
plot(tint/60,Cn(Nx,:),'LineStyle','-','LineWidth',2,'Color','green')
xlabel('Elapsed Time (min)','Interpreter','latex');
ylabel('Courant Number','Interpreter','latex');

% Rating Curve
% Solving for normal Depth
ymin = min(min(y));
ymax = max(max(y));
y_m = [ymin:0.01:ymax]'; % meters
hs = Nx/2; % half section
Qn = 1/nm(hs).*A_function(D,Z1,Z2,a,b,y_m).*Rh_function(D,Z1,Z2,a,b,y_m).^(2/3).*I0(hs)^0.5;
subplot(3,2,6)
plot(q2(Nx/2,:),y(Nx/2,:),'LineStyle',':','LineWidth',2,'Color','k')
hold on
plot(Qn,y_m,'LineStyle','-','LineWidth',2,'Color','k')
xlabel('Flow Discharge (m\textsuperscript{3}/s)','Interpreter','latex');
ylabel('Water Depth (m)','Interpreter','latex');
ylim([ymin ymax*1.2]);
l = legend('Q(L/2)','$Q_{n}$ (L/2)','Interpreter','Latex');
l.NumColumns = 2;
l.Location = 'north';
hold off
set(gcf,'units','inches','position',[0,0,7,12])
fig = sprintf('Summary_Charts%d.pdf',name_label);
exportgraphics(gcf,fig,'ContentType','vector')
clf
close all

% % Channel Width Chart
% h_f = figure;
% axis tight manual % this ensures that getframe() returns a consistent size
% filename = 'channel_width.gif';
% B2=B_function(D,Z1,Z2,a,b,y);
% for n=1:1:(Nt/Nat)
%     if n == 1
%         t = 1;
%         pos = 1;
%     else
%         t=(n-1)*Nat*dt;
%         pos = t/dt;
%     end
%     left_margin = B2(:,pos)/2; right_margin = -B2(:,pos)/2;
%     plot(x,left_margin,'k','LineWidth',2);
%     hold on
%     plot(x,right_margin,'k','LineWidth',2);
%     hold on
%     fill([x' fliplr(x')],[right_margin' fliplr(left_margin')],'blue')
%     xlabel('x [m]');
%     ylabel('B [m]');
%     ylim([1.1*min(min(-B2/2)), max(max(1.1*(B2/2)))]);
%     grid on
%     %legend('y(x,t)',2)
%     title(['t = ',num2str(round(t/60,2)),' [min]'])
%     drawnow
%     % Capture the plot as an image
%     frame = getframe(h_f);
%     im = frame2im(frame);
%     [imind,cm] = rgb2ind(im,256);
%     % Write to the GIF File
%     if n == 1
%         imwrite(imind,cm,filename,'gif', 'Loopcount',inf);
%     else
%         imwrite(imind,cm,filename,'gif','WriteMode','append');
%     end
%     hold off
% end
% clf
% close all

% Water Depth Profile
% h_f = figure;
% axis tight manual % this ensures that getframe() returns a consistent size
% filename = 'channel_wse_profile.gif';
% wse = inv_el + y; % water surface elevation in meters
% for n=1:1:(Nt/Nat)
%      if n == 1
%         t = 1;
%         pos = 1;
%     else
%         t=(n-1)*Nat*dt;
%         pos = t/dt;
%     end
%     plot(x,inv_el,'LineWidth',4,'LineStyle','-','Color','k')
%     hold on
%     plot(x,wse(:,pos),'k','LineWidth',2,'LineStyle','-','Color','blue')
%     fill([x' fliplr(x')], [inv_el' fliplr(wse(:,pos)')],'blue')
%     xlabel('x [m]','Interpreter','latex');
%     ylabel('Water surface Elevation [m]','Interpreter','latex');
%     ylim([0.98*min(min(wse - y)) max(max(1.01*wse))])
%     grid on
%     %legend('y(x,t)',2)
%     title(['t = ',num2str(round(t/60,2)),' [min]'])
%     drawnow
%     % Capture the plot as an image
%     frame = getframe(h_f);
%     im = frame2im(frame);
%     [imind,cm] = rgb2ind(im,256);
%     % Write to the GIF File
%     if n == 1
%         imwrite(imind,cm,filename,'gif', 'Loopcount',inf);
%     else
%         imwrite(imind,cm,filename,'gif','WriteMode','append');
%     end
%     hold off
%     %mov=addframe(mov,Mo); %Para gravar o vídeo, não comentar (excluir %)
% end
% close all
% 3D Channel Water Surface Elevation

%% Let's Calculate the Forces Associated with the Flow
h_person = 1.70; % m
b_person = 0.35; % m
gamma_water = 1000*9.81; % kg/m3
area_person = b_person*h_person;
velocity = q2./q1; % m/s
max_velocity = max(max(velocity));
h = y;

% Pressure due to velocity
p_vel = gamma_water*y.^2/(2*g); % N/m2

% Force due to velocity
F_vel = p_vel*area_person/1000/10; % tf

% Pressure due to water depth
p_depth = (gamma_water*h + gamma_water*(h - h_person))/2*h_person; % N/m2

% Force due to pressure
F_pressure = p_depth*area_person/1000/10; % tf

% Total Force
F_tot = F_vel + F_pressure;
max_force = max(max(F_tot));

%%  Video
fig = sprintf('Water_Surface_Elevation_Profile_%d.avi',name_label);
obj = VideoWriter(fig,'Motion JPEG AVI');
obj.Quality = 100;
obj.FrameRate = 20;
color_plot = [21, 179, 196]/255;
color_velocity = [255,99,71]/256;
color_force = [25,25,112]/256;
set(gcf,'units','inches','position',[0,0,7,12])
open(obj)
% Converting x to kilometers
x = x/1000;
for n=1:1:(Nt/Nat)
    hold off
    subplot(3,1,1)
    if n == 1
        t = 1;
        pos = 1;
    else
        t=(n-1)*Nat*dt;
        pos = t/dt;
    end
    Plot_Title = 'Time = %.2f (min)';
    sgtitle(sprintf(Plot_Title,t/60),'fontsize',18,'interpreter','latex')    
    plot(x,inv_el,'LineWidth',4,'LineStyle','-','Color','black')
    hold on
    plot(x,wse(:,pos),'LineWidth',2,'LineStyle','-','Color',color_plot)
    fill([x' fliplr(x')], [inv_el' fliplr(wse(:,pos)')],color_plot)
    xlabel('x [km]','Interpreter','latex');
    ylabel('Water surface Elevation [m]','Interpreter','latex');
    ylim([0.98*min(min(wse - y)) max(max(1.01*wse))])
    grid on
    title('Water Surface Elevation (m)','Interpreter','Latex');
    hold on
    % Plotting Positions
    x_dam = [Nx_r*dx, Nx_r*dx]/1000;
    y_dam = [inv_el(Nx_r), max(max(wse))];
    x_comunity = [Nx_comunity*dx, Nx_comunity*dx]/1000;
    y_comunity = [inv_el(Nx_comunity)  max(max(wse))];
    plot(x_dam,y_dam,'LineWidth',2,'LineStyle','--','Color','black')
    hold on
    plot(x_comunity,y_comunity,'LineWidth',2,'LineStyle','-.','Color','black')
    hold on     
    hold off


    subplot(3,1,2)
    velocity = q2(:,pos)./q1(:,pos);
    if n == 1
        t = 1;
        pos = 1;
    else
        t=(n-1)*Nat*dt;
        pos = t/dt;
    end
    zero_ground = inv_el*0;
    plot(x,velocity,'LineWidth',2,'LineStyle','-','Color',color_velocity)
    fill([x' fliplr(x')], [zero_ground' fliplr(velocity')],color_velocity)
    xlabel('x [km]','Interpreter','latex');
    ylabel('Velocity [m/s]','Interpreter','latex');
    ylim([0 max_velocity])
    grid on
    title('Velocity [m/s]','Interpreter','Latex');
    hold on
    % Plotting Positions
    x_dam = [Nx_r*dx, Nx_r*dx]/1000;
    y_dam = [0, max_velocity];
    x_comunity = [Nx_comunity*dx, Nx_comunity*dx]/1000;
    y_comunity = [0  max_velocity];
    hold on;
    plot(x_dam,y_dam,'LineWidth',2,'LineStyle','--','Color','black')
    hold on 
    plot(x_comunity,y_comunity,'LineWidth',2,'LineStyle','--','Color','black')
    hold off

    subplot(3,1,3)
    if n == 1
        t = 1;
        pos = 1;
    else
        t=(n-1)*Nat*dt;
        pos = t/dt;
    end
    plot(x,F_tot(:,pos),'LineWidth',2,'LineStyle','-','Color',color_force)
    fill([x' fliplr(x')], [zero_ground' fliplr(F_tot(:,pos)')],color_force)
    xlabel('x [km]','Interpreter','latex');
    ylabel('Force (tf)','Interpreter','latex');
    ylim([0 max_force]);
    grid on
    title('Force [tf]','Interpreter','Latex');
    hold on
    % Plotting Positions
    x_dam = [Nx_r*dx, Nx_r*dx]/1000;
    y_dam = [0, max_force];
    x_comunity = [Nx_comunity*dx, Nx_comunity*dx]/1000;
    y_comunity = [0  max_force];
    hold on;
    plot(x_dam,y_dam,'LineWidth',2,'LineStyle','--','Color','black')
    hold on 
    plot(x_comunity,y_comunity,'LineWidth',2,'LineStyle','--','Color','black')
    hold off

    f = getframe(gcf);
    writeVideo(obj,f);
    hold off    
end
obj.close();






