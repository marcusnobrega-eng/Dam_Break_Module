%% Dam Break Solver
% Developer: Marcus Nobrega
% Goal - Solve 1-D Hydrodynamics for Dam Break Cases

function [final_parameters,time_arrival] = Dam_Break_Function(label,y0_r, b_0, L_r, L_comunity, W_comunity, n_j, n_c,dt,tf,animation_time,Nx,el,I0)
clc
warning('off')

input = [label,y0_r, b_0, L_r, L_comunity, W_comunity, n_j, n_c,dt,tf,animation_time,Nx,el,I0];

% Dam Data
% The input data should be a row vector with
% 1 - Label of the dam
% 2 - Height of the dam in (m)
% 3 - Dam width (m)
% 4 - Dam Length (m)
% 5 - Length from the dam to the comunity (m)
% 6 - Length of the comunity (m)
% 7 - Roughness coefficient before the city
% 8 - Roughness coefficient after the city


name_label = input(1);
y0_r = input(2);
b_0 = input(3);
Lr = input(4);
L_comunity = input(5);
W_comunity = input(6);
nj = input(7);
nc = input(8);
nr = 0.012;
factor = 5;


% Time Inputs
% tf = 120; % End of simulation in minutes
% dt = 0.1; % time-step in seconds
% animation_time = 0.5; % Display animations in this time in minutes

% Problem Main Conditions - Dam Breach Problem
% Nx = 1000; % Number of sub-reaches in the channel
% el = 100; % invert elevation of inlet section (m)
% Lr = 275.6; % length of the reservoir (m)
% nr = 0.010; % manning's inside the reservoir (SI)
% nj = 0.015; % manning's coefficient after the dam but vefore the comunity
% nc = 0.013; % manning's in the comunity the reservoir (SI)
% b_0 = 156; % width of the channel (m)
% y0_r = 7; % Depth of water in the reservoir (m)
% I0 = 0.5/10000; % m/m average terrain slope
% L_comunity = 3895; % Distance from the dam to the comunity
% W_comunity = 1316; % Length of the comunity
Extra_Boundary_Domain = W_comunity*factor;
L = Lr + L_comunity + W_comunity + Extra_Boundary_Domain; % length of the channel in meters

% Times
tf = tf*60; % End of simulation in minutes

% Inflow Hydrograph
flag_hydrograph = 1; % If 1, enter the hydrograph, if 2, model using nash function
% 1st option - Enter Qe1 and Time below
if flag_hydrograph == 1
    Qe1 = [0 0]'; % Inflow hydrograph in m3/s
    time = [0 tf]'; % time of the hydrograph in minutes
else
    % 2nd option - Model the hydrograph using a nash function
    %%% Q(t) = Qb(t) + (Qp(t) - Qb(t))*(t/TP*EXP(1 - t/TP))^Beta
    Tp = 720; % min
    Qb = 1; % m3/s;
    Qp = 5; % m3/s;
    Beta = 8.5;
    Inflow_Hydrograph_fun = @(t)(Qb + (Qp - Qb).*(t/(Tp*60).*exp(1 - (t)/(Tp*60))).^Beta);
    time = [0 tf/60]'; % begin and and
end

% Outlet Boundary Condition
flag_outlet = 1; % 1 = normal depth, 2 = stage_hydrograph
if flag_outlet ~= 1
    %%% Wave Properties for Outlet Stage Hydrograph
    h_0_wave = 0.5; % mean wave depth (m)
    H_0_wave = 0.5 ; % wave amplitude (m)
    L_wave = 1000; % wave length in (m)
    T_wave = 24; % wave period in hours (m)
    x_wave = L_wave/1; % point position in wave x direction;
    k_wave = 2*pi/L_wave;
    sigma_wave = 2*pi./(T_wave*3600);
    h_wave_function = @(t)(h_0_wave + H_0_wave/2.*cos(k_wave.*x_wave - sigma_wave*t));
end

time = time*60; % time in seconds
[a1,~] = size(time);
tt_h = time(a1,1); % end of hydrograph in seconds
tt = min(tf,tt_h); % End of simulation in minutes
Nt = tt/dt; % Number of time-steps
Nat = animation_time*60/dt; % Number of time-steps within an animation time
tint = linspace(0,tt,Nt);
if flag_hydrograph == 1
    Qe1int = interp1(time,Qe1(:,1),tint,'pchip'); % Interpolated flow %Não utilizar spline;
    % pchip, que corresponde ao Hermite cúbico, é uma opção preferível.
    Qe1int = Qe1int';
else
    Qe1int = Inflow_Hydrograph_fun(tint)';
end

% Outlet Depth

% Channel Discretization

g = 9.806; % Gravity acceleration in m/s^2

dx = L/(Nx-1); % Channel discretization length in meters

% Friction Data
flag_friction = 1; % If 1, Manning, otherwise DW


%%% ---- Manning Profile ---- %%%
Nx_r = ceil(Lr / dx);
Nx_comunity = ceil((Lr + L_comunity)/dx);
for i = 1:Nx % Assigning manning to all cells
    if i <= Nx_r
        nm(i,1) = nr;
    elseif i <= Nx_comunity
        nm(i,1) = nj;
    else
        nm(i,1) = nc;
    end
end

% Pre-allocating arrays
% Matrices
x = (0:dx:L)'; % x discretization in meters
y = zeros(Nx,Nt);
q1 = zeros(Nx,Nt);
q2 = zeros(Nx,Nt);
f1 = zeros(Nx,Nt);
f2 = zeros(Nx,Nt);
J2 = zeros(Nx,Nt);
q1_back = q1(1:(Nx-2),Nt);
q1_foward = zeros(Nx-2,Nt);
q2_back = zeros(Nx-2,Nt);
q2_foward = zeros(Nx-2,Nt);
f1_back = zeros(Nx-2,Nt);
f1_foward = zeros(Nx-2,Nt);
f2_back = zeros(Nx-2,Nt);
f2_foward = zeros(Nx-2,Nt);
J2_back = zeros(Nx-2,Nt);
J2_foward = zeros(Nx-2,Nt);
ybar = zeros(Nx,Nt);
Fr = zeros(Nx,Nt);
Cn = zeros(Nx,Nt);

%% Channel Data (Cross Section)
sm = 1e-5; % Small number
b = sm; Z1 = sm; Z2 = sm; D = sm; a = sm;
flag_section = 1; % If 1, trapezoid, if 2, circular, if 3, paraboloid
if flag_section == 1
    % Assymetric Trapezoid
    b = b_0; % channel width in meters
    Z1 = 0; % cotang of left lateral inclination to horizon
    Z2 = 0; % cotang of rigyt lateral inclination to horizon
end

if flag_section == 2
    % Circular
    D = 2.85; % meters
end

if flag_section == 3
    % Parabolic Section
    a = 0.045; % y = a*x^2, (1/m)
end

% Slope
I0 = repmat(I0,Nx,1); % Bottom slope in m/m for all reaches

% Invert Elevations
inv_el = zeros(Nx,1);
for i = 1:Nx
    if i == 1
        inv_el(i) = el;
    else
        inv_el(i) = inv_el(i-1) - (I0(i)*dx);
    end
end
syms b_ y_ Z1_ Z2_ Q_ I0_ D_ a_
% Geometrical Functions
dim_all = 1e-6*(y_ + Z1_ + Z2_ + a_ + D_ + b_);
if flag_section == 1
    B = b_ + y_*(Z1_ + Z2_) + + dim_all; % user defined function (top width)
    B_function = matlabFunction(B);
    P = b_ + y_*(sqrt(1 + Z1_^2) + sqrt(1 + Z2_^2)) + dim_all; % Perimeter Function % user defined function
    P_function = matlabFunction(P);
    A = (2*b_ + y_*(Z1_ + Z2_))*y_/2 + dim_all; % Area function % user defined function
    A_function = matlabFunction(A); % Function describing the area in terms of y
    centroid = y_ - int(A,y_)./A + dim_all; % 1st order momentum
    ybar_function = matlabFunction(centroid); % Function describing ybar in terms of y
end
if flag_section == 2
    % Circular Section
    theta = 2*acos(1 - 2.*y_./D_) + dim_all;
    B = D_.*sin(theta/2) ; % top width
    B_function = matlabFunction(B);
    P = theta.*D_/2 ; % perimeter
    P_function = matlabFunction(P);
    A = D_.^2/8.*(theta - sin(theta)) ; % area
    A_function = matlabFunction(A); % Function describing the area in terms of y
    Ybar = y_ - (D_.*(- cos(theta/2)/2 + 2.*sin(theta/2).^3./(3*(theta - sin(theta))))); % Very much attention here
    ybar_function = matlabFunction(Ybar);
end
if flag_section == 3
    % Parabolic Section
    % Area Function
    A = 4.*(y_.^3/2)./(3*sqrt(a_)) + dim_all; % m2
    A_function = matlabFunction(A); % Function describing the area in terms of y
    % Top Width
    B = 3/2.*A./y_ + dim_all; % m
    B_function = matlabFunction(B);
    % Hydraulic Perimeter
    P = dim_all + sqrt(y_)./sqrt(a_).*(sqrt(1 + 4*a_.*y_) + 1./(2*a_).*(log(2*sqrt(a_).*sqrt(y_) + sqrt(1 + 4*a_.*y_))));
    P_function = matlabFunction(P);
    Y_bar = y_ - 2/5*y_ + dim_all;
    ybar_function = matlabFunction(Y_bar);
end

%%%%%%% Hydraulic Radius %%%%%%%
Rh = A/P; % Hydraulic Radius Function
Rh_function = matlabFunction(Rh); % Function describing the hydraulic radius in terms of y
%% Initial Boundary Conditions
Q0 = Qe1int(1,1); % Flow at inlet section at time 0
y0_c = 0.01; % Depth at other areas
y0 = zeros(Nx,1);
if flag_outlet == 1
    if flag_friction == 1
        for i = 1:Nx
            if i <= Nx_r
                y0(i,1) = y0_r;
            else
                y0(i,1) = y0_c;
            end
        end
        %       y0 = uniformeM(nm,Q0,b,Z1,Z2,a,D,I0,P,A)  ; % normal depth using manning equation
        % More Initial Boundary Conditions for Area, Velocity, Perimeter and Rh
        A0 = A_function(D,Z1,Z2,a,b,y0); % Cross section area in m
        u0 = (Q0./A0)'; % Initial velocity in m/s
        P0 = P_function(D,Z1,Z2,a,b,y0); % Hydraulic perimeter in m
        Rh0 = A0./P0; % Hydraulic radius at time 0
        y(:,1) = y0; % all sub-reaches with y0 at the beginning
        q1(:,1) = A0; % all sub-reaches with same area A0 at the beginning
        q2(:,1) = Q0; % Assuming permanent conditions at the beginning
        f1(:,1) = q2(:,1);
        % f2 depends on ybar
    else
        % YOU'VE GOT TO PROGRAM % normal depth using Darcy-Weisbach equation
    end
else
    steady_depth = uniformeM(nm,Q0,b,Z1,Z2,a,D,I0,P,A);
    y0(1:(Nx-1),1) = steady_depth(1:(Nx-1),1);
    % Stage Hydrograph Boundary Condition
    time_wave = 0; % time in seconds
    y0(Nx,1) = h_wave_function(time_wave);
    % More Initial Boundary Conditions for Area, Velocity, Perimeter and Rh
    A0 = A_function(D,Z1,Z2,a,b,y0); % Cross section area in m
    u0 = (Q0./A0)'; % Initial velocity in m/s
    P0 = P_function(D,Z1,Z2,a,b,y0); % Hydraulic perimeter in m
    Rh0 = A0./P0; % Hydraulic radius at time 0
    y(:,1) = y0(:,1); % all sub-reaches with y0 at the beginning
    q1(:,1) = A0(:,1); % all sub-reaches with same area A0 at the beginning
    q2(:,1) = Q0(:,1); % Assuming permanent conditions at the beginning
    f1(:,1) = q2(:,1);
    % f2 depends on ybar, we will calculate below
end

%%% State Space Format %%%
% dq/dt + dF/dx = S, we solve for A(x,t) and Q(x,t)
% q = [A Q]' = [q1 q2]'
% F [Q (Qv + gAybar]' = [q2 (q2^2)/q1 + g.q1.ybar]' = [f1 f2]'
% where ybar is the centroid depth from the top
% S = [0 gA(I0 - If)]'

% ybar = y - int(A(y)) / A(y) from y = 0 to y = y0
ybar = ybar_function(D,Z1,Z2,a,b,y0);
f2(:,1) = q2(:,1).*abs(q2(:,1))./q1(:,1) + g*q1(:,1).*ybar(:,1);

% Friction S = [J1 J2]' with J1 = 0 and J2 calculated as follows:
if flag_friction == 1
    J2(:,1) = g*q1(:,1).*(I0(:) - q2(:,1).*abs(q2(:,1)).*nm(:)./(q1(:,1).^2.*Rh0.^(4/3))); % Manning
else
    J2(:,1) = g*q1(:,1).*(I0(:) - f*q2(:,1).*abs(q2(:,1))./((q1(:,1).^2).*8*g.*Rh0)); % Darcy
end

% Froude Number
Fr(:,1)=abs(q2(:,1)./q1(:,1))./((g*A_function(D,Z1,Z2,a,b,y0)./B_function(D,Z1,Z2,a,b,y0)).^0.5);% Número de Froude

% Courant Number
% Cn = c / (dx / dt), where c = v + sqrt(g.Hm), where Hm = A / B
Hm = A_function(D,Z1,Z2,a,b,y0)./B_function(D,Z1,Z2,a,b,y0);
Cn(:,1)=(abs(q2(:,1)./q1(:,1))+(g*Hm).^0.5)/(dx/dt);% Courant Number

% Depth in terms of Area function
% let c be the area in terms of Z1,Z2,b, and y, such that A(y) = c
% we want to solve y for A(y) = csyms c
syms c_
fun_solve = (A - c_); % with c = area, we solve for y.
options = optimoptions ('fsolve', 'Display', 'none','FunctionTolerance',1e-2,'MaxFunctionEvaluations',Nx*10);
if flag_section == 1
    % We have an analytical solution for this case
    z = solve(fun_solve,y_); % solving for y_ = y and c = A(y)
    h_function = matlabFunction(z); % h(A) = z;
else
    % Non-linear set of equations for circular pipe, we need to use fsolve
end
fun_solve = matlabFunction(fun_solve); % Transforming into an equation
%% Main Loop %%
n = 1;
tic
for t = dt:dt:(tt - dt)

    n = n + 1;
    percentage_complete = t/(tt - dt)*100
    %%%%%%%%%%%%%% Boundary Conditions %%%%%%%%%%%%%%
    % Channel's begin (INLET)
    q1(1,n) = q1(2,n-1); % Area at section 1 is equals area of section 2 from previous time-step
    q2(1,n) = Qe1int(n,1); % Flow at section 1 is the inflow hydrograph

    if flag_section == 1 % Trapezoid or Rectangular
        if Z1 > 0 || Z2 > 0 % Trapezoidal channel
            y(1,n) = max(h_function(D,Z1,Z2,a,b,q1(1,n)')); % water depth in terms of area q1
            % In this previous function, we solve h = y in terms of A = q1 = c
        else
            y(1,n) = q1(1,n)/b; % water depth in terms of area q1 for rectangular channels
        end
    elseif flag_section > 1 % circular or paraboloid
        y0_guess = y(1,n-1);
        c = q1(1,n);  % It has to be a line vector
        fun = @(y_)fun_solve(D,Z1,Z2,a,b,c,y_);
        y(1,n) = fsolve(fun,y0_guess,options); % non-linear solver
    end
    % ybar
    ybar(1,n) = ybar_function(D,Z1,Z2,a,b,y(1,n));
    % f1 and f2
    f1(1,n) = q2(1,n);
    f2(1,n) = q2(1,n).*abs(q2(1,n))./q1(1,n) + g*q1(1,n).*ybar(1,n);
    % Hydraulic Radius
    Rh_inlet = Rh_function(D,Z1,Z2,a,b,y(1,n));
    % Friction
    if flag_friction == 1
        J2(1,n) = g*q1(1,n).*(I0(1) - q2(1,n).*abs(q2(1,n)).*nm(1).^2./(q1(1,n).^2*Rh_inlet.^(4/3))); % Manning
    else
        J2(1,n) = (I0(1) - f*q2(1,n).*abs(q2(1,n))./((q1(1,n).^2)*8*g.*Rh_inlet));
    end
    % Froude
    Fr(1,n)=abs(q2(1,n)./q1(1,n))./((g*A_function(D,Z1,Z2,a,b,y(1,n))./B_function(D,Z1,Z2,a,b,y(1,n)))^0.5);% Número de Froude
    % Courant
    Hm = A_function(D,Z1,Z2,a,b,y(1,n))./B_function(D,Z1,Z2,a,b,y(1,n));
    Cn(1,n)=(abs(q2(1,n)./q1(1,n))+(g*Hm).^0.5)/(dx/dt);% Courant Number

    % Right side of the channel (outlet)
    if flag_outlet == 1
        if flag_section == 1
            q1(Nx,n) = q1(Nx-1,n-1); % Area of outlet is the area of previous cell at previous time-step
            if Z1 > 0 || Z2 > 0
                y(Nx,n) = max(h_function(D,Z1,Z2,a,b,q1(Nx,n)')); % water depth in terms of area q1
            else
                y(Nx,n) = q1(Nx,n)/b; % water depth in terms of area q1 for rectangular channels
            end
        elseif flag_section >= 2 % circular or paraboloid
            % If we do not have an stage-hydrograph boundary condition
            y0_guess = y(Nx,n-1);
            c = q1(Nx,n);
            fun = @(y_)fun_solve(D,Z1,Z2,a,b,c,y_);
            y(Nx,n) = fsolve(fun,y0_guess,options); % non-linear solver
        end
    else
        % Stage Hydrograph Boundary Condition
        time_wave = n*dt; % time in seconds
        y(Nx,n) = h_wave_function(time_wave);
        q1(Nx,n) = A_function(D,Z1,Z2,a,b,y(Nx,n));
        %         q1(Nx,n) = q1(Nx-1,n-1)
    end
    % Hydraulic Radius
    Rh_outlet = Rh_function(D,Z1,Z2,a,b,y(Nx,n));
    if flag_friction == 1
        if flag_outlet == 1
            u = (1./nm(Nx)).*Rh_outlet^(2/3)*I0(Nx)^0.5; % Normal depth at the outlet
            flow_dir = 1;
        else
            depth_dif = y(Nx-1,n-1) + inv_el(Nx-1) - y(Nx,n) - inv_el(Nx); % Diference in wse
            out_slope = abs(depth_dif)/dx; % Flow slope at the outlet
            u = (1./nm(Nx)).*Rh_outlet^(2/3)*out_slope^0.5; % Normal depth at the outlet
            if depth_dif > 0
                flow_dir = 1;
            else
                flow_dir = -1;
            end
        end
    else
        u = sqrt(8*g*Rh_outlet*I0(Nx)/f); % outlet velocity
    end
    % Outlet Flow
    q2(Nx,n) = q1(Nx,n)*u*flow_dir; % Area x Velocity
    % ybar
    ybar(Nx,n) = ybar_function(D,Z1,Z2,a,b,y(Nx,n));
    % f1 and f2
    f1(Nx,n) = q2(Nx,n);
    f2(Nx,n) = q2(Nx,n).*abs(q2(Nx,n))./q1(Nx,n) + g*q1(Nx,n).*ybar(Nx,n);
    % J2
    % Friction
    if flag_friction == 1
        J2(Nx,n) = g*q1(Nx,n).*(I0(Nx) - q2(Nx,n).*abs(q2(Nx,n)).*nm(Nx)^2./(q1(Nx,n).^2*Rh_outlet.^(4/3))); % Manning
    else
        J2(Nx,n) = g*q1(Nx,n).*(I0(Nx) - f*q2(:,n).*abs(q2(Nx,n))./((q1(Nx,n).^2)*8*g*Rh_outlet));
    end
    % Froude
    Fr(Nx,n)=abs(q2(Nx,n)./q1(Nx,n))./((g*A_function(D,Z1,Z2,a,b,y(Nx,n))./B_function(D,Z1,Z2,a,b,y(Nx,n)))^0.5);% Número de Froude
    % Courant
    Hm = A_function(D,Z1,Z2,a,b,y(Nx,n))./B_function(D,Z1,Z2,a,b,y(Nx,n));
    Cn(Nx,n)=(abs(q2(Nx,n)./q1(Nx,n))+(g*Hm).^0.5)/(dx/dt);% Courant Number

    % Main Loop for Non Boundary Cells from 2 to (Nx - 1)
    % vectorized calculations
    q1_back = q1(1:(Nx-2),(n-1));
    q1_foward = q1(3:(Nx),(n-1));
    q2_back = q2(1:(Nx-2),(n-1));
    q2_foward = q2(3:(Nx),(n-1));
    f1_back = f1(1:(Nx-2),(n-1));
    f1_foward = f1(3:(Nx),(n-1));
    f2_back = f2(1:(Nx-2),(n-1));
    f2_foward = f2(3:(Nx),(n-1));
    J2_back = J2(1:(Nx-2),(n-1));
    J2_foward = J2(3:(Nx),(n-1));

    x_i = 2:(Nx-1); % vector for interior sections varying from 2 to (Nx - 1)
    % Lax-Friedrichs Method
    % Given an hyperbolic partial derivative system of equations described
    % by:
    % pq/pt + pF/px - S = 0, where p is the partial derivative, one can
    % solve this equation by performing a foward discretization for q and a
    % central discretization for F. Moreover, S = (Sback + Sfoward)/2
    % Expliciting the system of equations for q1, it follows that

    q1(x_i,n) = 0.5.*(q1_foward + q1_back) - 0.5*dt/dx*(f1_foward - f1_back); %% attention here in f1foward
    q2(x_i,n) = 0.5*(q2_foward + q2_back) - 0.5*dt/dx*(f2_foward - f2_back) + 0.5*dt*(J2_back + J2_foward);

    if flag_section == 1
        if Z1>0 || Z2>0
            y(x_i,n) = max(h_function(D,Z1,Z2,a,b,q1(x_i,n)')); % water depth in terms of area q1
        else
            y(x_i,n)=q1(x_i,n)/b;
        end
    elseif flag_section > 1
        y0_guess = y(x_i,n-1);
        c = q1(x_i,n); % It has to be a line vector
        fun = @(y_)fun_solve(D,Z1,Z2,a,b,c,y_);
        y(x_i,n) = fsolve(fun,y0_guess,options); % non-linear solver
    end
    % Hydraulic Radius
    Rh_middle = Rh_function(D,Z1,Z2,a,b,y(x_i,n));
    % ybar
    ybar(x_i,n) = ybar_function(D,Z1,Z2,a,b,y(x_i,n));
    % f1 and f2
    f1(x_i,n) = q2(x_i,n);
    f2(x_i,n) = q2(x_i,n).*abs(q2(x_i,n))./q1(x_i,n) + g*q1(x_i,n).*ybar(x_i,n);
    % Froude
    Hm = A_function(D,Z1,Z2,a,b,y(x_i,n))./B_function(D,Z1,Z2,a,b,y(x_i,n));
    Fr(x_i,n)=abs(q2(x_i,n)./q1(x_i,n))./((g*Hm).^0.5);% Número de Froude
    % Courant
    Cn(x_i,n)=(abs(q2(x_i,n)./q1(x_i,n))+(g*Hm).^0.5)/(dx/dt);% Courant Number
    % Friction
    if flag_friction == 1
        J2(x_i,n) = g*q1(x_i,n).*(I0(x_i) - q2(x_i,n).*abs(q2(x_i,n).*nm(x_i).^2./(q1(x_i,n).^2.*Rh_middle.^(4/3))));
    else
        J2(x_i,n) = g*q1(x_i,n).*(I0(x_i) - f*q2(x_i,n).*abs(q2(x_i,n))./((q1(x_i,n).^2)*8*g*Rh_midle));
    end
    % Stability Check
    if max(Cn(:,n)) > 1
        error('Please, decrease the time-step')
    end
end

%%% Post Processing Figures %%%
% Call function
warning('on');
post_processing
ttttt = toc;

velocity = q2./q1; % m/s
zzz = find(y(Nx_comunity,:) == max(y(Nx_comunity,:)),1,'first');
kkk = find(velocity(Nx_comunity,:) == max(velocity(Nx_comunity,:)));
time_arrival = find(y());
final_parameters = [ttttt/60, dt, tf/60, dx, zzz*dt/60, max(y(Nx_comunity,:)), velocity(Nx_comunity,zzz),  kkk*dt/60 , max(y(Nx_comunity,kkk)) , velocity(Nx_comunity,kkk) ];


headers = [{'Computational Time (min)'},{'Time-step (sec)'},{'Simulation Time (min)'},{'Spatial Discretization (m)'},{'Arrival time of maximum depth (min)'},{'Maximum Depth (m)'},{'Velocity at maximum depth (m/s)'},{'Arrival of maximum velocity (min)'},{'Depth at the arrival of the maximum velocity (m)'},{'Maximum velocity (m/s)'}];
data_save = [final_parameters]; % Concatenating dataset to the time
T = array2table(data_save);
T.Properties.VariableNames(1:size(data_save,2)) = headers;
name = sprintf('Summary_Output ID - %d.csv',name_label);
writetable(T,name,'Delimiter',',');

disp('Attention: Data exported in .CSV');


% Exporting Data


end